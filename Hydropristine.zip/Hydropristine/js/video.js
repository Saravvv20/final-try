var video = document.getElementById("myVideo");


var btn = document.getElementById("myBtn");


